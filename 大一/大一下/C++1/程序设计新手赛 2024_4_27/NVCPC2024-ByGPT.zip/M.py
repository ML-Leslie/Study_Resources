# https://chat.openai.com/share/c051b2c0-4693-4049-9d71-b60bf1fc6abb
import sys

# Read the input expression from stdin
expression = input().strip()

# Split the expression based on the bit-or operators
parts = expression.split('|')

# Evaluate each part separately and combine the results using bit-or
result = 0
for part in parts:
    # Evaluate the part using eval() with proper operator priorities
    part_result = eval(part.replace('^', '**'))
    # Combine the results using bit-or
    result |= part_result

# Print the result
print(result)
