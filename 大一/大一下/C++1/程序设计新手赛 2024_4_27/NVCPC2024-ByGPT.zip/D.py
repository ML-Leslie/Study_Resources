# https://sl.bing.net/hyRera8k2Ro
# https://chat.openai.com/share/b1e9adec-e17b-47ef-af41-fb6f2258036d
d = int(input())  # Input integer d
a = d // 2  # Calculate a based on d
b = 2 * a  # Calculate b based on a
c = 3 * a  # Calculate c based on a

if a > 0 and b > a and c > b and d == c - a:  # Check if conditions are satisfied
    print(c, b, a)  # Print c, b, a if conditions are met
else:
    print("Impossible")  # Print "Impossible" if conditions are not met
