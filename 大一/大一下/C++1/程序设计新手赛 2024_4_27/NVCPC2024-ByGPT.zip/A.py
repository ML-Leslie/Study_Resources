# https://chat.openai.com/share/82c44b44-ca01-41f7-bbc9-1474c0e52db8
print("BCD")

