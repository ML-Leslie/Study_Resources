// https://chat.openai.com/share/fbed60f9-b78b-42fd-8425-12d4fb3879a0
#include <iostream>

int findMode(int n) {
    int mode = 0; // Initialize the mode candidate
    int count = 0; // Initialize the count of mode candidate occurrences

    for (int i = 0; i < n; ++i) {
        int num;
        std::cin >> num; // Read the numbers one by one

        if (count == 0) {
            mode = num; // Set the current number as the mode candidate
            count = 1; // Start counting occurrences from 1
        } else if (mode == num) {
            ++count; // Increment count if the current number matches mode candidate
        } else {
            --count; // Decrement count if the current number is different
        }
    }

    return mode; // Return the mode candidate as the final result
}

int main() {
    int n;
    std::cin >> n; // Read the number of elements

    int mode = findMode(n); // Find the mode

    std::cout << mode << std::endl; // Output the mode number only
    return 0;
}

