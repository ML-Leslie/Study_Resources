// https://chat.openai.com/share/96004232-ce5f-4c45-a1d2-12d965326d12
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

// Function to calculate the sum of two vectors
vector<int> addVectors(const vector<int>& vec1, const vector<int>& vec2) {
    vector<int> result(vec1.size());
    for (size_t i = 0; i < vec1.size(); ++i) {
        result[i] = vec1[i] + vec2[i];
    }
    return result;
}

// Function to check if two vectors are equal
bool vectorsEqual(const vector<int>& vec1, const vector<int>& vec2) {
    for (size_t i = 0; i < vec1.size(); ++i) {
        if (vec1[i] != vec2[i]) {
            return false;
        }
    }
    return true;
}

// Recursive function to find the number of possible selections
int countPossibleSelections(const vector<vector<int>>& selections, const vector<int>& target, size_t index, vector<int> currentSum) {
    if (index == selections.size()) {
        // Check if the current sum equals the target vector
        if (vectorsEqual(currentSum, target)) {
            return 1;
        }
        return 0;
    }

    // Include the current selection in the sum
    int countWithCurrent = countPossibleSelections(selections, target, index + 1, addVectors(currentSum, selections[index]));

    // Exclude the current selection from the sum
    int countWithoutCurrent = countPossibleSelections(selections, target, index + 1, currentSum);

    return countWithCurrent + countWithoutCurrent;
}

int main() {
    int n, m;
    cin >> n >> m;

    vector<int> target(m);
    for (int i = 0; i < m; ++i) {
        cin >> target[i];
    }

    vector<vector<int>> selections(n, vector<int>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> selections[i][j];
        }
    }

    int result = countPossibleSelections(selections, target, 0, vector<int>(m, 0));
    cout << result << endl;

    return 0;
}

